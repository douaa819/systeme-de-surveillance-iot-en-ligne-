<?php
require_once 'config.php';

$sensor_values = [
    "Température" => rand(20, 60),
    "Humidité" => rand(10, 100),
    "Luminosité" => rand(100, 1000)
];

$sql = "SELECT * FROM thresholds";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $sensor = $row['sensor'];
        $threshold = $row['threshold_value'];
        $value = $sensor_values[$sensor];

        echo "Capteur : $sensor | Valeur : $value | Seuil : $threshold <br>";

        if ($value > $threshold) {
            $insert_sql = "INSERT INTO alerts (sensor, value, threshold) VALUES ('$sensor', $value, $threshold)";
            if ($conn->query($insert_sql)) {
                echo "🚀 Alerte insérée pour $sensor <br>";
            } else {
                echo "❌ Erreur MySQL : " . $conn->error . "<br>";
            }
        } else {
            echo "✅ Pas d'alerte pour $sensor <br>";
        }
    }
} else {
    echo "❌ Aucun seuil trouvé dans la base de données.";
}

$conn->close();
?>
